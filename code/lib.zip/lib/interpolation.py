# This code is made available as part of the FRIB-TA Summer School:
# A Practical Walk Through Formal Scattering Theory: Connecting Bound States,
# Resonances, and Scattering States in Exotic Nuclei and Beyond, held
# virtually August 4-6, 2021.
#
# https://fribtascattering.github.io/
#
# Organizers/Lecturers:
# - Kévin Fossez (MSU/ANL)
# - Sebastian König (NCSU)
# - Heiko Hergert (MSU)
#
# Author: Sebastian König
#
# Last update: Aug 11, 2021

# This implements the global spline interpolation described in
# Glöckle et al., Z. Phys. A 305, 217 (1982).

import numpy as np
import bisect as bs

class GlobalSplineInterpolator:
  def __init__(self, xs):
    self.xs = xs

    self.n = len(self.xs)

    hs = np.diff(xs, prepend=0)

    ls = np.zeros(self.n - 1)
    ms = np.zeros(self.n - 1)

    for i in range(0, self.n - 1):
      ls[i] = hs[i + 1] / (hs[i] + hs[i + 1])
      ms[i] = 1.0 - ls[i]

    ps = np.zeros(self.n - 1)
    qs = np.zeros(self.n - 1)

    for i in range(1, self.n - 1):
      ps[i] = ms[i] * qs[i - 1] + 2.0
      qs[i] = -ls[i] / ps[i]

    A = np.zeros((self.n, self.n - 1))
    B = np.zeros((self.n, self.n - 1))

    for i in range(0, self.n):
      for j in range(1, self.n - 1):
        B[i, j] = -6.0 / (hs[j] * hs[j + 1]) * (i == j) \
          + 6.0 / ((hs[j] + hs[j + 1]) * hs[j + 1]) * (i == j + 1) \
          + 6.0 / ((hs[j] + hs[j + 1]) * hs[j]) * (i == j - 1)
        A[i, j] = B[i, j] / ps[j] - ms[j] / ps[j] * A[i, j - 1]

    C = np.zeros((self.n, self.n))

    for i in range(0, self.n):
      for j in range(self.n - 2, -1, -1):
        C[i, j] = qs[j] * C[i, j + 1] + A[i, j]

    self.S1 = np.zeros((self.n, self.n))
    self.S2 = np.zeros((self.n, self.n))
    self.S3 = np.zeros((self.n, self.n))

    for i in range(0, self.n):
      for j in range(0, self.n - 1):
        self.S1[i, j] = (1.0 * (i == j + 1) - 1.0 * (i == j))/ hs[j + 1] \
          - hs[j + 1] / 6.0 * (2.0 * C[i, j] + C[i, j + 1])
        self.S2[i, j] = 0.5 * C[i, j]
        self.S3[i, j] = (C[i, j + 1] - C[i, j]) / (6.0 * hs[j + 1])

  def get_index(self, x0):
    return bs.bisect_left(self.xs, x0)

  def __call__(self, fs, x0):
    j = self.get_index(x0)

    result = 0.0
    for i in range(0, self.n):
      result += fs[i] * self.S(i, x0, j)

    return result

  def S(self, i, x0, j=-1):
    if j < 0:
      j = self.get_index(x0)

    h = x0 - self.xs[j]

    return 1.0 * (i == j) \
      + h * self.S1[i, j] + h**2 * self.S2[i, j] + h**3 * self.S3[i, j]
