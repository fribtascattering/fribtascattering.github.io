# This code is made available as part of the FRIB-TA Summer School:
# "A Practical Walk Through Formal Scattering Theory: Connecting Bound States,
# Resonances, and Scattering States in Exotic Nuclei and Beyond," held
# virtually August 4-6, 2021.
#
# https://fribtascattering.github.io/
#
# Organizers/Lecturers:
# - Kévin Fossez (MSU/ANL)
# - Sebastian König (NCSU)
# - Heiko Hergert (MSU)
#
# Author: Sebastian König
#
# Last update: Aug 11, 2021

import numpy as np

class Mesh:
  def __init__(self, n, p_min, p_max):
    self.n = n
    self.p_min = p_min
    self.p_max = p_max

    self.pv_points = []
    self.pv_weights = []

  def ps(self):
    return np.append(self.points, self.pv_points)

  def ws(self):
    return np.append(self.weights, self.pv_weights)

  def p(self, i):
    return self.ps()[i]

  def w(self, i):
    return self.ws()[i]

  def pws(self):
    return zip( \
      self.ps(), self.ws(), \
      np.append(np.full(self.n, False), np.full(len(self.pv_points), True)) \
    )

  def size(self):
    return self.n + len(self.pv_points)

  def n_pv(self, i=0):
    return self.n + i

  def push_pv(self, p0, ipi=True):
    R = sum(map(lambda pw: pw[1] / (p0 - pw[0]), self.pws())) \
      + np.log((self.p_max - p0) / (p0 - self.p_min))

    if ipi:
      R += 1j * np.pi

    self.pv_points.append(p0)
    self.pv_weights.append(R)

    return len(self.points) + len(self.pv_points) - 1

  def pop_pv(self):
    self.pv_points.pop()
    self.pv_weights.pop()

class GaulegMesh(Mesh):
  def __init__(self, n, p_min, p_max):
    super().__init__(n, p_min, p_max)

    self.points, self.weights = np.polynomial.legendre.leggauss(n)

    for i in range(n):
      self.points[i] = 0.5 * (self.points[i] + 1.0) * (p_max - p_min) + p_min
      self.weights[i] = 0.5 * self.weights[i] * (p_max - p_min)

class ExpGaulegMesh(GaulegMesh):
  def __init__(self, n, p_min, p_max):
    super().__init__(n, np.log(1.0 + p_min), np.log(1.0 + p_max))

    self.p_min = p_min
    self.p_max = p_max

    for i in range(n):
      self.points[i] = np.exp(self.points[i])
      self.weights[i] = self.weights[i] * self.points[i]
      self.points[i] -= 1.0
